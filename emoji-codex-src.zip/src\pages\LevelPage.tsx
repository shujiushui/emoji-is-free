import { useEffect, useState } from "react";
import { Navigate, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, ArrowRight, Shuffle, Sparkles } from "lucide-react";
import { getLevel, levels } from "@/data/levels";
import { useProgress } from "@/store/progress";
import { useHistory } from "@/store/history";
import { shuffle } from "@/lib/shuffle";
import { tellStory } from "@/lib/narrator";
import SortableList, { type SortableItem } from "@/components/SortableList";
import ResultReveal from "@/components/ResultReveal";

function makeItems(levelId: number, emojis: string[]): SortableItem[] {
  return shuffle(emojis).map((emoji, i) => ({ id: `${levelId}-${i}`, emoji }));
}

export default function LevelPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const levelId = Number(id);
  const level = getLevel(levelId);
  const isUnlocked = useProgress((s) => s.isUnlocked);
  const complete = useProgress((s) => s.complete);
  const addHistory = useHistory((s) => s.add);

  const [items, setItems] = useState<SortableItem[]>(() =>
    level ? makeItems(level.id, level.emojis) : [],
  );
  const [revealed, setRevealed] = useState(false);
  const [story, setStory] = useState("");

  // 切换关卡时重置
  useEffect(() => {
    if (!level) return;
    setItems(makeItems(level.id, level.emojis));
    setRevealed(false);
    setStory("");
  }, [level]);

  if (!level) return <Navigate to="/" replace />;
  if (!isUnlocked(level.id)) return <Navigate to="/" replace />;

  const isLast = level.id === levels[levels.length - 1].id;

  const handleDecode = () => {
    const emojis = items.map((it) => it.emoji);
    const text = tellStory(emojis);
    setStory(text);
    setRevealed(true);
    complete(level.id);
    addHistory({
      levelId: level.id,
      levelTitle: level.title,
      emojis,
      story: text,
    });
  };

  const handleShuffle = () => {
    setItems(makeItems(level.id, level.emojis));
    setRevealed(false);
    setStory("");
  };

  const goNext = () => {
    if (isLast) navigate("/");
    else navigate(`/level/${level.id + 1}`);
  };

  return (
    <div className="flex min-h-screen flex-col">
      {/* 顶部栏 */}
      <header className="flex items-center justify-between px-4 pt-5 sm:px-6 sm:pt-7">
        <button
          onClick={() => navigate("/")}
          className="inline-flex items-center gap-1.5 rounded-lg border border-gold/40 bg-paper-200/60 px-3 py-2 font-display text-sm text-ink-soft transition-colors hover:bg-gold/10"
        >
          <ArrowLeft size={16} /> 地图
        </button>
        <div className="text-center">
          <div className="font-display text-[11px] tracking-[0.25em] text-gold">
            CHAPTER {level.id} / {levels.length}
          </div>
          <div className="font-display text-lg font-semibold text-ink sm:text-xl">
            {level.title}
          </div>
        </div>
        <div className="w-[72px]" aria-hidden />
      </header>

      {/* 提示 */}
      <p className="mt-1 px-4 text-center font-display text-sm italic text-gold sm:px-6">
        {level.hint}
      </p>

      {/* 主体 */}
      <main className="mx-auto flex w-full max-w-lg flex-1 flex-col px-4 pb-8 pt-5 sm:px-6">
        <div className="mb-3 flex items-center justify-between">
          <span className="font-display text-sm text-ink-soft">
            左右拖动方块，排出你想要的顺序
          </span>
          <button
            onClick={handleShuffle}
            className="inline-flex items-center gap-1 rounded-md px-2 py-1 font-display text-xs text-clay transition-colors hover:bg-clay/10"
          >
            <Shuffle size={13} /> 打乱
          </button>
        </div>

        {/* 横向排序区 */}
        <div className="rounded-2xl border border-gold/30 bg-paper-200/30 p-3 shadow-inset sm:p-4">
          <SortableList
            items={items}
            onChange={(next) => {
              setItems(next);
              // 重新排列后收起旧故事，等待再次解读
              if (revealed) {
                setRevealed(false);
                setStory("");
              }
            }}
          />
        </div>

        {/* 结果揭示 */}
        <div className="mt-5">
          <ResultReveal text={story} open={revealed} />
        </div>

        {/* 底部操作 */}
        <div className="mt-auto flex items-center gap-3 pt-6">
          {revealed ? (
            <>
              <button
                onClick={handleShuffle}
                className="flex-1 rounded-xl border border-gold/50 bg-paper-200/60 px-4 py-3.5 font-display text-base font-semibold text-ink-soft transition-colors hover:bg-gold/10"
              >
                再排一次
              </button>
              <button
                onClick={goNext}
                className="flex flex-[1.4] items-center justify-center gap-2 rounded-xl bg-sage px-4 py-3.5 font-display text-lg font-semibold text-paper shadow-paper transition-all hover:bg-sage-dark hover:shadow-lift active:translate-y-px"
              >
                {isLast ? "回到地图" : "下一关"}
                <ArrowRight size={18} />
              </button>
            </>
          ) : (
            <button
              onClick={handleDecode}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-clay px-6 py-3.5 font-display text-lg font-semibold text-paper shadow-paper transition-all hover:bg-clay-dark hover:shadow-lift active:translate-y-px"
            >
              <Sparkles size={18} />
              解读密语
            </button>
          )}
        </div>

        {!revealed && (
          <p className="mt-2 text-center font-display text-xs text-ink-soft/70">
            排好后点击解读，看看这组符号讲了什么故事
          </p>
        )}
      </main>
    </div>
  );
}
