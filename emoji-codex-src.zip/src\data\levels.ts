export interface Level {
  id: number;
  title: string;
  hint: string;
  /** 本关出现的 emoji 集合（6~7 个，无固定顺序，由玩家自由排列） */
  emojis: string[];
}

export const levels: Level[] = [
  {
    id: 1,
    title: "寻常一日",
    hint: "这些符号组成了一天的片段，由你来决定它们如何发生",
    emojis: ["🌅", "👟", "🚶", "☕", "💻", "📱", "😴"],
  },
  {
    id: 2,
    title: "猫咪的午后",
    hint: "关于一只猫的午后，把它们排成一个小故事",
    emojis: ["🐱", "🐟", "🍽️", "😋", "😺", "💤"],
  },
  {
    id: 3,
    title: "种下一棵树",
    hint: "一粒种子的若干片段，按你想象的顺序讲述它",
    emojis: ["🌱", "💧", "☀️", "🌿", "🌳", "🍎"],
  },
  {
    id: 4,
    title: "冬夜小屋",
    hint: "雪夜、小屋与温暖的片段，串成一段时光",
    emojis: ["❄️", "🏠", "🔥", "📖", "☕", "😴"],
  },
  {
    id: 5,
    title: "登月旅行",
    hint: "从地球到月亮的符号，排成你心中的旅程",
    emojis: ["🚀", "🌍", "⭐", "🌙", "👨‍🚀", "🏠"],
  },
  {
    id: 6,
    title: "生日派对",
    hint: "派对上的欢乐瞬间，随意排列，读出一个故事",
    emojis: ["🎈", "🎂", "🕯️", "👏", "🎁", "🎵", "🕺"],
  },
];

export const getLevel = (id: number): Level | undefined =>
  levels.find((l) => l.id === id);
