import { Check, Lock } from "lucide-react";
import type { MouseEvent } from "react";
import { cn } from "@/lib/utils";
import type { Level } from "@/data/levels";

export type NodeStatus = "locked" | "available" | "done";

interface Props {
  level: Level;
  status: NodeStatus;
  current?: boolean;
  /** 刚刚解锁：播放扩散光环等一次性反馈 */
  unlocking?: boolean;
  onClick?: (e: MouseEvent) => void;
}

export default function LevelNode({
  level,
  status,
  current,
  unlocking,
  onClick,
}: Props) {
  const interactive = status !== "locked";
  const firstEmoji = level.emojis[0];

  const Wrapper = interactive ? "button" : "div";

  return (
    <Wrapper
      onClick={interactive ? onClick : undefined}
      disabled={!interactive}
      className={cn(
        "group flex w-32 flex-col items-center gap-1.5 text-center outline-none sm:w-36",
        interactive && "cursor-pointer transition-transform duration-300 hover:-translate-y-1",
        !interactive && "cursor-not-allowed",
      )}
    >
      <div
        className={cn(
          "relative flex h-20 w-20 items-center justify-center rounded-full border-4 transition-all duration-300 sm:h-24 sm:w-24",
          status === "done" &&
            "border-paper bg-sage text-white shadow-paper",
          status === "available" &&
            "border-clay bg-paper-200 text-ink shadow-paper",
          status === "locked" &&
            "border-gold/30 bg-paper-300/50 text-ink-soft/60",
          current && status === "available" && "animate-breath border-clay",
          unlocking && "animate-breath",
        )}
      >
        {/* 完成：勾选 + 原 emoji 淡显 */}
        {status === "done" ? (
          <>
            <span className="absolute text-2xl opacity-40 sm:text-3xl">
              {firstEmoji}
            </span>
            <Check
              className="relative drop-shadow"
              size={30}
              strokeWidth={3}
            />
          </>
        ) : (
          <span
            className={cn(
              "text-3xl sm:text-4xl",
              status === "locked" && "grayscale opacity-50",
            )}
          >
            {firstEmoji}
          </span>
        )}

        {/* 锁定遮罩 */}
        {status === "locked" && (
          <Lock
            className="absolute text-gold/70"
            size={18}
            strokeWidth={2.5}
          />
        )}

        {/* 当前关卡小旗帜 */}
        {current && status === "available" && (
          <span className="absolute -top-2 right-1 rounded bg-clay px-1.5 py-0.5 font-display text-[10px] font-semibold text-paper shadow">
            当前
          </span>
        )}

        {/* 解锁反馈：扩散光环 + 上升徽章 */}
        {unlocking && (
          <>
            <span className="pointer-events-none absolute inset-0 rounded-full border-[3px] border-clay animate-unlock" />
            <span
              className="pointer-events-none absolute inset-0 rounded-full border-[3px] border-gold animate-unlock"
              style={{ animationDelay: "0.25s" }}
            />
            <span className="pointer-events-none absolute -top-6 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-clay px-2 py-0.5 font-display text-[10px] font-semibold text-paper shadow animate-badgeUp">
              已解锁
            </span>
          </>
        )}
      </div>

      <div className="leading-tight">
        <div
          className={cn(
            "font-display text-[11px] tracking-wide text-gold",
            status === "locked" && "opacity-60",
          )}
        >
          第 {level.id} 章
        </div>
        <div
          className={cn(
            "font-display text-base font-semibold sm:text-lg",
            status === "locked" ? "text-ink-soft/60" : "text-ink",
          )}
        >
          {level.title}
        </div>
      </div>
    </Wrapper>
  );
}
