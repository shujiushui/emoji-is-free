import { useState } from "react";
import { History, Lock, RotateCcw, ScrollText } from "lucide-react";
import { getLevel, levels, type Level } from "@/data/levels";
import { useProgress, currentLevelId } from "@/store/progress";
import { useHistory } from "@/store/history";
import LevelNode, { type NodeStatus } from "@/components/LevelNode";
import LevelOverlay from "@/components/LevelOverlay";
import HistoryPanel from "@/components/HistoryPanel";
import { cn } from "@/lib/utils";

interface Pt {
  x: number;
  y: number;
}

/** Catmull-Rom 样条转三次贝塞尔，生成平滑蜿蜒路径 */
function smoothPath(pts: Pt[]): string {
  if (pts.length < 2) return "";
  const pt = (i: number) => pts[Math.max(0, Math.min(pts.length - 1, i))];
  let d = `M ${pts[0].x} ${pts[0].y}`;
  for (let i = 1; i < pts.length; i++) {
    const p0 = pt(i - 2);
    const p1 = pt(i - 1);
    const p2 = pt(i);
    const p3 = pt(i + 1);
    const cp1x = p1.x + (p2.x - p0.x) / 6;
    const cp1y = p1.y + (p2.y - p0.y) / 6;
    const cp2x = p2.x - (p3.x - p1.x) / 6;
    const cp2y = p2.y - (p3.y - p1.y) / 6;
    d += ` C ${cp1x.toFixed(2)} ${cp1y.toFixed(2)}, ${cp2x.toFixed(
      2,
    )} ${cp2y.toFixed(2)}, ${p2.x} ${p2.y}`;
  }
  return d;
}

export default function MapPage() {
  const completed = useProgress((s) => s.completed);
  const isUnlocked = useProgress((s) => s.isUnlocked);
  const isCompleted = useProgress((s) => s.isCompleted);
  const reset = useProgress((s) => s.reset);
  const historyCount = useHistory((s) => s.entries.length);

  const [tip, setTip] = useState<string | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);

  // 悬停预览：哪个节点 + 光标位置
  const [hoverId, setHoverId] = useState<number | null>(null);
  const [cursor, setCursor] = useState({ x: 0, y: 0 });

  // 全屏覆盖层：当前关卡 + 放大原点（视口百分比）
  const [active, setActive] = useState<{
    level: Level;
    origin: { x: number; y: number };
  } | null>(null);
  // 记录在覆盖层里刚完成的关卡，用于关闭时触发下一关解锁动画
  const [lastCompleted, setLastCompleted] = useState<number | null>(null);
  // 正在播放解锁动画的节点
  const [unlockingId, setUnlockingId] = useState<number | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [historyOpen, setHistoryOpen] = useState(false);

  const current = currentLevelId(completed);
  const total = levels.length;
  const doneCount = completed.length;
  const progress = Math.round((doneCount / total) * 100);

  // 节点在容器内的百分比坐标：x 用正弦形成蜿蜒，y 均匀分布并留白
  const points: Pt[] = levels.map((_, i) => ({
    x: 50 + 33 * Math.sin(i * 1.15 + 0.4),
    y: ((i + 0.8) / (total + 0.6)) * 100,
  }));
  const pathD = smoothPath(points);

  const triggerUnlock = (id: number) => {
    setUnlockingId(id);
    setToast(`第 ${id} 章 已解锁`);
    window.setTimeout(() => setUnlockingId(null), 1600);
    window.setTimeout(() => setToast(null), 2000);
  };

  const openLevel = (level: Level, clientX: number, clientY: number) => {
    const origin = {
      x: (clientX / window.innerWidth) * 100,
      y: (clientY / window.innerHeight) * 100,
    };
    setActive({ level, origin });
    setHoverId(null);
  };

  const handleNodeClick = (level: Level, e: React.MouseEvent) => {
    if (isUnlocked(level.id)) {
      openLevel(level, e.clientX, e.clientY);
    } else {
      setTip(`先完成第 ${level.id - 1} 章，才能解开这一章`);
      window.setTimeout(() => setTip(null), 2200);
    }
  };

  const handleClose = () => {
    // 关闭覆盖层时，若刚完成的关卡解锁了「下一章」，播放解锁反馈
    if (lastCompleted != null) {
      const nextId = lastCompleted + 1;
      const next = getLevel(nextId);
      if (next && isUnlocked(nextId) && !isCompleted(nextId)) {
        triggerUnlock(nextId);
      }
    }
    setLastCompleted(null);
    setActive(null);
  };

  const handleNextLevel = (nextId: number) => {
    const next = getLevel(nextId);
    if (!next) return;
    setActive({ level: next, origin: { x: 50, y: 50 } });
  };

  // 悬停预览卡片所需数据
  const hoveredLevel = hoverId != null ? getLevel(hoverId) : null;
  const hoveredStatus: NodeStatus | null = hoveredLevel
    ? isCompleted(hoveredLevel.id)
      ? "done"
      : isUnlocked(hoveredLevel.id)
        ? "available"
        : "locked"
    : null;

  // 预览卡片位置：避开屏幕右/下边缘
  let cardX = cursor.x + 16;
  let cardY = cursor.y + 16;
  if (typeof window !== "undefined") {
    if (cursor.x + 16 > window.innerWidth - 240) cardX = cursor.x - 240;
    if (cursor.y + 16 > window.innerHeight - 170) cardY = cursor.y - 170;
  }

  return (
    <div className="min-h-screen w-full px-4 pb-20 pt-10 sm:px-6 sm:pt-14">
      <div
        className="mx-auto w-full max-w-2xl"
        onMouseMove={(e) => setCursor({ x: e.clientX, y: e.clientY })}
      >
        {/* 顶部标题 */}
        <header className="animate-fadeUp text-center">
          <div className="mb-3 flex items-center justify-center gap-2 text-gold">
            <ScrollText size={18} strokeWidth={2} />
            <span className="font-display text-xs tracking-[0.3em] uppercase">
              Emoji Codex
            </span>
          </div>
          <h1 className="font-display text-5xl font-extrabold leading-none text-ink sm:text-6xl">
            Emoji 密语
          </h1>
          <p className="mx-auto mt-4 max-w-md font-display text-base italic text-ink-soft sm:text-lg">
            拖动散落的字符，随意排列，读出符号里藏着的小故事。
          </p>

          {/* 进度条 */}
          <div className="mx-auto mt-6 max-w-sm">
            <div className="mb-1.5 flex items-center justify-between font-display text-xs text-gold">
              <span>解读进度</span>
              <span>
                {doneCount} / {total}
              </span>
            </div>
            <div className="h-2.5 overflow-hidden rounded-full border border-gold/40 bg-paper-300/50">
              <div
                className="h-full rounded-full bg-gradient-to-r from-sage to-sage-dark transition-all duration-700 ease-out"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>

          {doneCount === total && (
            <p className="mt-5 animate-fadeUp font-display text-lg font-semibold text-sage-dark">
              全部密语已解读，你写下了属于自己的符号故事集！
            </p>
          )}
        </header>

        {/* 地图长卷 */}
        <div className="relative mt-10 h-[640px] w-full sm:h-[820px]">
          {/* 背景羊皮纸卡片 */}
          <div className="absolute inset-0 rounded-3xl border border-gold/30 bg-paper-200/40 shadow-inset" />

          {/* 路径 SVG（拉伸填充，描边不缩放） */}
          <svg
            viewBox="0 0 100 100"
            preserveAspectRatio="none"
            className="absolute inset-0 h-full w-full"
            aria-hidden
          >
            {/* 路径阴影 */}
            <path
              d={pathD}
              fill="none"
              stroke="#9A7B3F"
              strokeOpacity="0.18"
              strokeWidth="5"
              strokeLinecap="round"
              vectorEffect="non-scaling-stroke"
            />
            {/* 主路径：虚线流动 */}
            <path
              d={pathD}
              fill="none"
              stroke="#9A7B3F"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeDasharray="5 7"
              vectorEffect="non-scaling-stroke"
              className="animate-dash"
            />
            {/* 站点小圆点 */}
            {points.map((p, i) => (
              <circle
                key={i}
                cx={p.x}
                cy={p.y}
                r="1.4"
                fill="#B5481E"
                vectorEffect="non-scaling-stroke"
              />
            ))}
          </svg>

          {/* 关卡节点 */}
          {levels.map((level, i) => {
            const status: NodeStatus = completed.includes(level.id)
              ? "done"
              : isUnlocked(level.id)
                ? "available"
                : "locked";
            const isCurrent = level.id === current && status === "available";
            const p = points[i];
            return (
              <div
                key={level.id}
                className="absolute animate-fadeUp"
                style={{
                  left: `${p.x}%`,
                  top: `${p.y}%`,
                  transform: "translate(-50%, -50%)",
                  animationDelay: `${0.15 + i * 0.08}s`,
                }}
                onMouseEnter={() => setHoverId(level.id)}
                onMouseLeave={() => setHoverId((cur) => (cur === level.id ? null : cur))}
              >
                <LevelNode
                  level={level}
                  status={status}
                  current={isCurrent}
                  unlocking={unlockingId === level.id}
                  onClick={(e) => handleNodeClick(level, e)}
                />
              </div>
            );
          })}
        </div>

        {/* 底部操作 */}
        <div className="mt-8 flex items-center justify-center gap-3">
          <button
            onClick={() => {
              const lvl = getLevel(current);
              if (lvl) openLevel(lvl, window.innerWidth / 2, window.innerHeight / 2);
            }}
            className="rounded-xl bg-clay px-6 py-2.5 font-display text-base font-semibold text-paper shadow-paper transition-all hover:bg-clay-dark hover:shadow-lift active:translate-y-px"
          >
            继续解读 · 第 {current} 章
          </button>
          <button
            onClick={() => setConfirmReset(true)}
            className="rounded-xl border border-gold/50 px-4 py-2.5 font-display text-sm text-gold transition-colors hover:bg-gold/10"
          >
            <span className="inline-flex items-center gap-1.5">
              <RotateCcw size={15} /> 重置进度
            </span>
          </button>
          <button
            onClick={() => setHistoryOpen(true)}
            className="relative rounded-xl border border-gold/50 px-4 py-2.5 font-display text-sm text-gold transition-colors hover:bg-gold/10"
          >
            <span className="inline-flex items-center gap-1.5">
              <History size={15} /> 历史记录
            </span>
            {historyCount > 0 && (
              <span className="absolute -right-1.5 -top-1.5 flex h-5 min-w-[20px] items-center justify-center rounded-full bg-clay px-1 font-display text-[11px] font-semibold text-paper shadow-paper">
                {historyCount > 99 ? "99+" : historyCount}
              </span>
            )}
          </button>
        </div>

        {/* 悬停预览小卡片：从光标处冒出 */}
        {hoveredLevel && hoveredStatus && !active && (
          <div
            className="pointer-events-none fixed z-40 w-[220px] animate-fadeUp rounded-xl border border-gold/40 bg-paper-200/95 p-3 shadow-lift backdrop-blur"
            style={{ left: cardX, top: cardY }}
          >
            <div className="mb-1.5 flex items-center justify-between">
              <span className="font-display text-[11px] tracking-wide text-gold">
                第 {hoveredLevel.id} 章
              </span>
              <span
                className={cn(
                  "font-display text-[10px]",
                  hoveredStatus === "done" && "text-sage-dark",
                  hoveredStatus === "available" && "text-clay",
                  hoveredStatus === "locked" && "text-ink-soft/60",
                )}
              >
                {hoveredStatus === "done"
                  ? "已解读"
                  : hoveredStatus === "available"
                    ? "可挑战"
                    : "未解锁"}
              </span>
            </div>
            <div className="mb-2 font-display text-sm font-semibold text-ink">
              {hoveredLevel.title}
            </div>

            {hoveredStatus === "locked" ? (
              <div className="flex items-center gap-1.5 py-1 text-xs text-ink-soft/70">
                <Lock size={13} className="text-gold" />
                完成上一章后解锁
              </div>
            ) : (
              <div className="flex flex-wrap gap-1">
                {hoveredLevel.emojis.map((e, idx) => (
                  <span
                    key={idx}
                    className="flex h-7 w-7 items-center justify-center rounded-md border border-gold/30 bg-paper text-base leading-none"
                  >
                    {e}
                  </span>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* 轻提示 */}
      {tip && !active && (
        <div className="pointer-events-none fixed bottom-8 left-1/2 z-50 -translate-x-1/2 animate-fadeUp rounded-full border border-gold/40 bg-paper-200 px-5 py-2.5 font-display text-sm text-ink shadow-lift">
          {tip}
        </div>
      )}

      {/* 解锁提示 */}
      {toast && (
        <div className="pointer-events-none fixed top-8 left-1/2 z-50 -translate-x-1/2 animate-fadeUp rounded-full border border-clay/50 bg-clay px-5 py-2.5 font-display text-sm font-semibold text-paper shadow-lift">
          🔓 {toast}
        </div>
      )}

      {/* 全屏覆盖层：排列 + 解读 */}
      {active && (
        <LevelOverlay
          key={active.level.id}
          level={active.level}
          origin={active.origin}
          onClose={handleClose}
          onComplete={(id) => setLastCompleted(id)}
          onNextLevel={handleNextLevel}
        />
      )}

      {/* 重置确认 */}
      {confirmReset && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/40 px-4 backdrop-blur-sm">
          <div className="animate-fadeUp w-full max-w-xs rounded-2xl border border-gold/40 bg-paper p-6 text-center shadow-lift">
            <p className="font-display text-lg font-semibold text-ink">
              要清空所有解读进度吗？
            </p>
            <p className="mt-1 text-sm text-ink-soft">此操作无法撤销</p>
            <div className="mt-5 flex justify-center gap-3">
              <button
                onClick={() => setConfirmReset(false)}
                className="rounded-lg border border-gold/40 px-4 py-2 text-sm text-ink-soft hover:bg-gold/10"
              >
                再想想
              </button>
              <button
                onClick={() => {
                  reset();
                  setConfirmReset(false);
                }}
                className={cn(
                  "rounded-lg bg-clay px-4 py-2 text-sm font-semibold text-paper hover:bg-clay-dark",
                )}
              >
                确认重置
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 历史排列与记录抽屉 */}
      <HistoryPanel open={historyOpen} onClose={() => setHistoryOpen(false)} />
    </div>
  );
}
