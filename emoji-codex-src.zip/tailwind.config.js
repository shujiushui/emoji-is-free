/** @type {import('tailwindcss').Config} */

export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    container: {
      center: true,
    },
    extend: {
      colors: {
        paper: {
          DEFAULT: "#F3EAD8",
          200: "#EFE4CD",
          300: "#E6D7B8",
          400: "#D9C69C",
        },
        ink: {
          DEFAULT: "#2B241D",
          soft: "#5C4F42",
        },
        clay: {
          DEFAULT: "#B5481E",
          dark: "#8F3917",
          light: "#D96A3A",
        },
        sage: {
          DEFAULT: "#4E7C59",
          dark: "#3A5E43",
        },
        gold: {
          DEFAULT: "#9A7B3F",
        },
      },
      fontFamily: {
        display: ["Fraunces", "Georgia", "Songti SC", "SimSun", "serif"],
        sans: ["DM Sans", "PingFang SC", "Microsoft YaHei", "system-ui", "sans-serif"],
      },
      boxShadow: {
        paper: "0 1px 0 rgba(43,36,29,0.04), 0 10px 30px -12px rgba(43,36,29,0.25)",
        lift: "0 18px 40px -14px rgba(43,36,29,0.45)",
        inset: "inset 0 1px 0 rgba(255,255,255,0.5), inset 0 -8px 24px -12px rgba(43,36,29,0.18)",
      },
      keyframes: {
        breath: {
          "0%, 100%": { boxShadow: "0 0 0 0 rgba(181,72,30,0.45)" },
          "50%": { boxShadow: "0 0 0 14px rgba(181,72,30,0)" },
        },
        stampIn: {
          "0%": { transform: "scale(2.2) rotate(-22deg)", opacity: "0" },
          "60%": { transform: "scale(0.92) rotate(-8deg)", opacity: "1" },
          "100%": { transform: "scale(1) rotate(-10deg)", opacity: "1" },
        },
        fadeUp: {
          "0%": { opacity: "0", transform: "translateY(14px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        dash: {
          to: { strokeDashoffset: "-28" },
        },
        unlockRing: {
          "0%": { transform: "scale(0.7)", opacity: "0.85" },
          "70%": { opacity: "0.3" },
          "100%": { transform: "scale(2.6)", opacity: "0" },
        },
        badgeUp: {
          "0%": { transform: "translateY(6px) scale(0.8)", opacity: "0" },
          "30%": { transform: "translateY(-4px) scale(1.05)", opacity: "1" },
          "70%": { transform: "translateY(-10px) scale(1)", opacity: "1" },
          "100%": { transform: "translateY(-22px) scale(0.95)", opacity: "0" },
        },
      },
      animation: {
        breath: "breath 2.4s ease-in-out infinite",
        stampIn: "stampIn 0.5s cubic-bezier(.2,1.4,.4,1) both",
        fadeUp: "fadeUp 0.6s ease both",
        dash: "dash 1.6s linear infinite",
        unlock: "unlockRing 1.4s ease-out forwards",
        badgeUp: "badgeUp 1.5s ease-out forwards",
      },
    },
  },
  plugins: [],
};
