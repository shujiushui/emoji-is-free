import { create } from "zustand";
import { persist } from "zustand/middleware";

/** 一条历史记录：玩家当时的排列顺序 + 生成的故事 */
export interface HistoryEntry {
  id: string;
  levelId: number;
  levelTitle: string;
  /** 玩家排出的 emoji 顺序 */
  emojis: string[];
  /** 当时生成的故事文本 */
  story: string;
  createdAt: number;
}

interface HistoryState {
  entries: HistoryEntry[];
  add: (entry: Omit<HistoryEntry, "id" | "createdAt">) => void;
  remove: (id: string) => void;
  clear: () => void;
}

/** 最多保留的记录条数，避免 localStorage 无限增长 */
const MAX_ENTRIES = 60;

export const useHistory = create<HistoryState>()(
  persist(
    (set) => ({
      entries: [],
      add: (entry) =>
        set((s) => {
          const newEntry: HistoryEntry = {
            ...entry,
            id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
            createdAt: Date.now(),
          };
          // 新记录置顶，超出上限则丢弃最旧的
          return { entries: [newEntry, ...s.entries].slice(0, MAX_ENTRIES) };
        }),
      remove: (id) =>
        set((s) => ({ entries: s.entries.filter((e) => e.id !== id) })),
      clear: () => set({ entries: [] }),
    }),
    { name: "emoji-whispers-history" },
  ),
);
