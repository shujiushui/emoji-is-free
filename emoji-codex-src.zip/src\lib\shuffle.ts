/** Fisher–Yates 洗牌，保证结果与原顺序不同 */
export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  // 若偶然与原顺序一致，则整体右移一位
  if (a.length > 1 && a.every((v, i) => v === arr[i])) {
    a.unshift(a.pop()!);
  }
  return a;
}
