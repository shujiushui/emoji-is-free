import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import MapPage from "@/pages/MapPage";
import LevelPage from "@/pages/LevelPage";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<MapPage />} />
        <Route path="/level/:id" element={<LevelPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}
