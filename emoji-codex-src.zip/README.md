# Emoji 密语 · Emoji Codex

> 拖动散落的 emoji 字符，随意排列，读出符号里藏着的小故事。

一款轻量的纯前端互动小游戏：每一关给出一组 emoji（6~7 个），你把它们横向排成任意顺序，点击「解读密语」后，叙述器会根据这组符号生成一段发散而猎奇的文字小故事。一张羊皮卷风格的闯关地图把所有章节串联起来，每解读一章便解锁下一章。

## 玩法

1. 在地图上选择一个已解锁的章节节点。
2. 进入后**左右拖动** emoji 小方块，排出你想要的顺序。
3. 点击「解读密语」，即可看到这组符号讲述的故事（打字机逐字显现）。
4. 解读后自动解锁下一章；随时可以「再排一次」，不同顺序会讲出不同的故事。
5. 所有排过的排列与生成的故事，都会自动收进地图页的「历史记录」。

## 功能特性

- 🗺️ **羊皮卷闯关地图**：蜿蜒路径串联全部章节，节点带未解锁 / 可挑战 / 已完成状态。
- ✨ **悬停预览 + 点击放大**：地图节点悬停时从光标处冒出小卡片展示可用 emoji；点击后小卡片从点击点放大覆盖全屏进行排列。
- 🔓 **解锁视觉反馈**：完成一章后，下一章节点播放扩散光环与「已解锁」徽章动画。
- 🎲 **任意排列皆成故事**：不再判定正确或错误，顺序不同 → 短语、标点节奏、猎奇收尾都会变化。
- 📜 **无连接词的蒙太奇叙述**：去掉「然后 / 最后 / 接着」等连接词，纯靠短句与标点节奏（逗号、句号、破折号）形成画面流；同一种排列永远生成同一个故事（稳定哈希）。
- 🕘 **历史排列与记录**：地图页提供历史抽屉，回看每次的排列顺序与生成的故事，可单条删除或清空。
- 💾 **本地持久化**：闯关进度与历史记录都存于浏览器 `localStorage`，刷新不丢失。

## 技术栈

| 类别 | 选型 |
|------|------|
| 框架 | React 18 + TypeScript |
| 构建 | Vite 6 |
| 样式 | Tailwind CSS 3（羊皮卷 / 手稿风格，自定义色板与动效） |
| 路由 | react-router-dom 7 |
| 状态 | zustand + `persist` 中间件（localStorage 持久化） |
| 图标 | lucide-react |
| 拖拽 | 基于 Pointer Events 自研横向排序（无第三方拖拽库） |
| 字体 | Fraunces（展示）+ DM Sans（正文），中文回退系统字体 |

纯前端单页应用，无后端、无外部服务。

## 本地运行

需要 Node.js 18+。

```bash
# 安装依赖
npm install

# 启动开发服务器（默认 http://localhost:5173）
npm run dev

# 类型检查
npm run check

# 构建生产产物（输出到 dist/）
npm run build

# 本地预览构建产物
npm run preview
```

## 目录结构

```
.
├── index.html              # 入口 HTML（注入字体与主题色）
├── package.json
├── vite.config.ts          # Vite 配置（路径别名、sourcemap）
├── tsconfig.json
├── tailwind.config.js      # 自定义色板 / 字体 / 动效关键帧
├── postcss.config.js
├── eslint.config.js
├── public/
│   └── favicon.svg
├── src/
│   ├── main.tsx            # 应用入口
│   ├── App.tsx             # 路由容器 + 全局纸张背景
│   ├── index.css           # Tailwind 入口与全局样式
│   ├── data/
│   │   └── levels.ts       # 静态关卡数据（6 章）
│   ├── pages/
│   │   ├── MapPage.tsx     # 地图主页：路径、节点、解锁反馈、历史入口
│   │   └── LevelPage.tsx   # 独立路由的关卡页（/level/:id）
│   ├── components/
│   │   ├── LevelNode.tsx       # 地图关卡节点（状态 + 解锁动画）
│   │   ├── LevelOverlay.tsx    # 点击节点后全屏放大的排列面板
│   │   ├── SortableList.tsx    # 自研横向 Pointer Events 拖拽排序
│   │   ├── ResultReveal.tsx    # 打字机效果的故事揭示
│   │   └── HistoryPanel.tsx    # 历史排列与记录抽屉
│   ├── store/
│   │   ├── progress.ts     # 闯关进度（key: emoji-whispers-progress）
│   │   └── history.ts      # 历史记录（key: emoji-whispers-history）
│   └── lib/
│       ├── narrator.ts     # 叙述器：短语池 + 稳定哈希生成故事
│       ├── shuffle.ts      # 洗牌
│       └── utils.ts        # cn() 等工具
└── .trae/documents/        # 设计过程文档（PRD / 技术架构，以源码为准）
    ├── prd.md
    └── technical-architecture.md
```

## 设计文档

`.trae/documents/` 下保留了产品需求文档（PRD）与技术架构文档，记录了早期设计思路。注意：其中部分描述（如纵向排列、含 `meaning` 字段等）已在迭代中调整，**当前实现以源码为准**。

## 部署到 GitHub Pages

本项目是纯前端 SPA，可直接部署到 GitHub Pages：

1. 若仓库名不是 `<用户名>.github.io`，需在 [vite.config.ts](vite.config.ts) 中设置 `base: '/<仓库名>/'`，否则资源路径会 404。
2. 构建：`npm run build`，产物在 `dist/`。
3. 把 `dist/` 内容推送到 `gh-pages` 分支，或使用 [gh-pages](https://www.npmjs.com/package/gh-pages) 工具一键发布：
   ```bash
   npm run build
   npx gh-pages -d dist
   ```
4. 在仓库 Settings → Pages 选择 `gh-pages` 分支作为来源。

> 注意：路由使用 `BrowserRouter`，刷新子路由（如 `/level/2`）在 Pages 上可能 404。如需子路由可直接刷新，可改用 `HashRouter`，或在 Pages 配置 404 回退到 `index.html`。

## License

MIT
