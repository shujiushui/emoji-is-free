import { create } from "zustand";
import { persist } from "zustand/middleware";
import { levels } from "@/data/levels";

interface ProgressState {
  completed: number[];
  complete: (id: number) => void;
  reset: () => void;
  isUnlocked: (id: number) => boolean;
  isCompleted: (id: number) => boolean;
}

export const useProgress = create<ProgressState>()(
  persist(
    (set, get) => ({
      completed: [],
      complete: (id) =>
        set((s) =>
          s.completed.includes(id) ? s : { completed: [...s.completed, id] },
        ),
      reset: () => set({ completed: [] }),
      isUnlocked: (id) => {
        if (id <= 1) return true;
        return get().completed.includes(id - 1);
      },
      isCompleted: (id) => get().completed.includes(id),
    }),
    { name: "emoji-whispers-progress" },
  ),
);

/** 第一个「未完成且已解锁」的关卡，即当前应挑战的关卡 */
export function currentLevelId(completed: number[]): number {
  return levels.find((l) => !completed.includes(l.id))?.id ?? levels[0].id;
}
