import { useCallback, useEffect, useState } from "react";
import { ArrowRight, Shuffle, Sparkles, X } from "lucide-react";
import type { Level } from "@/data/levels";
import { levels } from "@/data/levels";
import { useProgress } from "@/store/progress";
import { useHistory } from "@/store/history";
import { shuffle } from "@/lib/shuffle";
import { tellStory } from "@/lib/narrator";
import SortableList, { type SortableItem } from "@/components/SortableList";
import ResultReveal from "@/components/ResultReveal";

interface Props {
  level: Level;
  /** 放大动画的原点（视口百分比），通常为点击位置 */
  origin: { x: number; y: number };
  onClose: () => void;
  /** 解读完成后通知父级（用于触发解锁动画） */
  onComplete?: (id: number) => void;
  /** 点击下一关时通知父级切换到指定关卡 */
  onNextLevel?: (nextId: number) => void;
}

function makeItems(levelId: number, emojis: string[]): SortableItem[] {
  return shuffle(emojis).map((emoji, i) => ({ id: `${levelId}-${i}`, emoji }));
}

const TRANSITION_MS = 280;

export default function LevelOverlay({
  level,
  origin,
  onClose,
  onComplete,
  onNextLevel,
}: Props) {
  const complete = useProgress((s) => s.complete);
  const addHistory = useHistory((s) => s.add);

  const [items, setItems] = useState<SortableItem[]>(() =>
    makeItems(level.id, level.emojis),
  );
  const [revealed, setRevealed] = useState(false);
  const [story, setStory] = useState("");
  const [entered, setEntered] = useState(false);
  const [leaving, setLeaving] = useState(false);

  const isLast = level.id === levels[levels.length - 1].id;

  // 关卡切换时重置
  useEffect(() => {
    setItems(makeItems(level.id, level.emojis));
    setRevealed(false);
    setStory("");
  }, [level]);

  // 入场：下一帧触发展开动画
  useEffect(() => {
    const t = window.setTimeout(() => setEntered(true), 16);
    return () => window.clearTimeout(t);
  }, []);

  // ESC 关闭
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") requestClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const requestClose = useCallback(() => {
    if (leaving) return;
    setLeaving(true);
    setEntered(false);
    window.setTimeout(onClose, TRANSITION_MS);
  }, [leaving, onClose]);

  const handleDecode = () => {
    const emojis = items.map((it) => it.emoji);
    const text = tellStory(emojis);
    setStory(text);
    setRevealed(true);
    complete(level.id);
    addHistory({
      levelId: level.id,
      levelTitle: level.title,
      emojis,
      story: text,
    });
    onComplete?.(level.id);
  };

  const handleShuffle = () => {
    setItems(makeItems(level.id, level.emojis));
    setRevealed(false);
    setStory("");
  };

  const handleNext = () => {
    if (isLast) requestClose();
    else onNextLevel?.(level.id + 1);
  };

  const originStyle = {
    transformOrigin: `${origin.x}% ${origin.y}%`,
  } as const;

  return (
    <div className="fixed inset-0 z-50">
      {/* 背景遮罩：展开过程中逐渐压暗地图 */}
      <div
        className="absolute inset-0 bg-ink/50 backdrop-blur-sm transition-opacity duration-300"
        style={{ opacity: entered && !leaving ? 1 : 0 }}
        onClick={requestClose}
      />

      {/* 全屏面板：从点击点放大覆盖整个界面 */}
      <div
        className="absolute inset-0 flex flex-col bg-paper shadow-lift transition-[transform,opacity] duration-300 ease-[cubic-bezier(.2,.8,.2,1)] will-change-transform"
        style={{
          ...originStyle,
          transform: entered && !leaving ? "scale(1)" : "scale(0.2)",
          opacity: entered && !leaving ? 1 : 0,
        }}
      >
        {/* 噪点纹理（与全局风格一致） */}
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 opacity-[0.05] mix-blend-multiply"
          style={{
            backgroundImage:
              "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")",
          }}
        />

        <div className="relative flex min-h-0 flex-1 flex-col overflow-y-auto">
          {/* 顶部栏 */}
          <header className="flex items-center justify-between px-4 pt-5 sm:px-6 sm:pt-7">
            <button
              onClick={requestClose}
              className="inline-flex items-center gap-1.5 rounded-lg border border-gold/40 bg-paper-200/60 px-3 py-2 font-display text-sm text-ink-soft transition-colors hover:bg-gold/10"
            >
              <X size={16} /> 关闭
            </button>
            <div className="text-center">
              <div className="font-display text-[11px] tracking-[0.25em] text-gold">
                CHAPTER {level.id} / {levels.length}
              </div>
              <div className="font-display text-lg font-semibold text-ink sm:text-xl">
                {level.title}
              </div>
            </div>
            <div className="w-[72px]" aria-hidden />
          </header>

          {/* 提示 */}
          <p className="mt-1 px-4 text-center font-display text-sm italic text-gold sm:px-6">
            {level.hint}
          </p>

          {/* 主体 */}
          <main className="mx-auto flex w-full max-w-lg flex-1 flex-col px-4 pb-8 pt-5 sm:px-6">
            <div className="mb-3 flex items-center justify-between">
              <span className="font-display text-sm text-ink-soft">
                左右拖动方块，排出你想要的顺序
              </span>
              <button
                onClick={handleShuffle}
                className="inline-flex items-center gap-1 rounded-md px-2 py-1 font-display text-xs text-clay transition-colors hover:bg-clay/10"
              >
                <Shuffle size={13} /> 打乱
              </button>
            </div>

            {/* 横向排序区 */}
            <div className="rounded-2xl border border-gold/30 bg-paper-200/30 p-3 shadow-inset sm:p-4">
              <SortableList
                items={items}
                onChange={(next) => {
                  setItems(next);
                  if (revealed) {
                    setRevealed(false);
                    setStory("");
                  }
                }}
              />
            </div>

            {/* 结果揭示 */}
            <div className="mt-5">
              <ResultReveal text={story} open={revealed} />
            </div>

            {/* 底部操作 */}
            <div className="mt-auto flex items-center gap-3 pt-6">
              {revealed ? (
                <>
                  <button
                    onClick={handleShuffle}
                    className="flex-1 rounded-xl border border-gold/50 bg-paper-200/60 px-4 py-3.5 font-display text-base font-semibold text-ink-soft transition-colors hover:bg-gold/10"
                  >
                    再排一次
                  </button>
                  <button
                    onClick={handleNext}
                    className="flex flex-[1.4] items-center justify-center gap-2 rounded-xl bg-sage px-4 py-3.5 font-display text-lg font-semibold text-paper shadow-paper transition-all hover:bg-sage-dark hover:shadow-lift active:translate-y-px"
                  >
                    {isLast ? "回到地图" : "下一关"}
                    <ArrowRight size={18} />
                  </button>
                </>
              ) : (
                <button
                  onClick={handleDecode}
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-clay px-6 py-3.5 font-display text-lg font-semibold text-paper shadow-paper transition-all hover:bg-clay-dark hover:shadow-lift active:translate-y-px"
                >
                  <Sparkles size={18} />
                  解读密语
                </button>
              )}
            </div>

            {!revealed && (
              <p className="mt-2 text-center font-display text-xs text-ink-soft/70">
                排好后点击解读，看看这组符号讲了什么故事
              </p>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
