import { useEffect, useState } from "react";
import { History, Trash2, X } from "lucide-react";
import { useHistory, type HistoryEntry } from "@/store/history";

interface Props {
  open: boolean;
  onClose: () => void;
}

function formatTime(ts: number): string {
  const d = new Date(ts);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getMonth() + 1}/${d.getDate()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function EntryCard({
  entry,
  onRemove,
}: {
  entry: HistoryEntry;
  onRemove: () => void;
}) {
  const [confirmDel, setConfirmDel] = useState(false);
  return (
    <div className="rounded-xl border border-gold/30 bg-paper-200/40 p-3.5 shadow-inset">
      <div className="mb-2 flex items-center justify-between gap-2">
        <div className="min-w-0">
          <span className="font-display text-[11px] tracking-[0.18em] text-gold">
            第 {entry.levelId} 章
          </span>
          <span className="ml-2 font-display text-sm font-semibold text-ink">
            {entry.levelTitle}
          </span>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <span className="font-display text-[11px] text-ink-soft/70">
            {formatTime(entry.createdAt)}
          </span>
          <button
            onClick={() => setConfirmDel(true)}
            aria-label="删除这条记录"
            className="rounded-md p-1 text-ink-soft/50 transition-colors hover:bg-clay/10 hover:text-clay"
          >
            <Trash2 size={14} />
          </button>
        </div>
      </div>

      {/* 当时的排列顺序 */}
      <div className="mb-2.5 flex flex-wrap gap-1">
        {entry.emojis.map((e, i) => (
          <span
            key={i}
            className="flex h-7 w-7 items-center justify-center rounded-md border border-gold/30 bg-paper text-base leading-none shadow-sm"
          >
            {e}
          </span>
        ))}
      </div>

      {/* 生成的故事 */}
      <p className="font-display text-[15px] leading-relaxed text-ink-soft">
        {entry.story}
      </p>

      {confirmDel && (
        <div className="mt-3 flex items-center justify-end gap-2 border-t border-gold/20 pt-2.5">
          <span className="mr-auto font-display text-xs text-ink-soft">
            删除这条记录？
          </span>
          <button
            onClick={() => setConfirmDel(false)}
            className="rounded-md border border-gold/40 px-3 py-1 font-display text-xs text-ink-soft transition-colors hover:bg-gold/10"
          >
            取消
          </button>
          <button
            onClick={onRemove}
            className="rounded-md bg-clay px-3 py-1 font-display text-xs font-semibold text-paper transition-colors hover:bg-clay-dark"
          >
            删除
          </button>
        </div>
      )}
    </div>
  );
}

export default function HistoryPanel({ open, onClose }: Props) {
  const entries = useHistory((s) => s.entries);
  const remove = useHistory((s) => s.remove);
  const clear = useHistory((s) => s.clear);
  const [confirmClear, setConfirmClear] = useState(false);

  // ESC 关闭
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (confirmClear) setConfirmClear(false);
        else onClose();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose, confirmClear]);

  return (
    <>
      {/* 遮罩 */}
      <div
        aria-hidden
        className={`fixed inset-0 z-40 bg-ink/40 backdrop-blur-sm transition-opacity duration-300 ${
          open ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
        onClick={onClose}
      />

      {/* 右侧抽屉 */}
      <aside
        className={`fixed right-0 top-0 z-50 flex h-full w-full max-w-md flex-col bg-paper shadow-lift transition-transform duration-300 ease-[cubic-bezier(.2,.8,.2,1)] ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
        aria-hidden={!open}
      >
        {/* 顶部栏 */}
        <header className="flex items-center justify-between border-b border-gold/30 px-5 py-4">
          <div className="flex items-center gap-2">
            <History size={18} className="text-gold" />
            <h2 className="font-display text-lg font-semibold text-ink">
              历史排列
            </h2>
            {entries.length > 0 && (
              <span className="rounded-full bg-gold/15 px-2 py-0.5 font-display text-[11px] text-gold">
                {entries.length}
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            className="inline-flex items-center gap-1.5 rounded-lg border border-gold/40 bg-paper-200/60 px-3 py-2 font-display text-sm text-ink-soft transition-colors hover:bg-gold/10"
          >
            <X size={16} /> 关闭
          </button>
        </header>

        {/* 列表 */}
        <div className="flex-1 overflow-y-auto px-5 py-4">
          {entries.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full border border-dashed border-gold/40 bg-paper-200/40">
                <History size={26} className="text-gold/70" />
              </div>
              <p className="font-display text-base font-semibold text-ink">
                还没有任何解读记录
              </p>
              <p className="mt-1.5 max-w-[15rem] font-display text-sm leading-relaxed text-ink-soft">
                去地图上排一组符号并解读，写下的故事会自动收在这里。
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {entries.map((entry) => (
                <EntryCard
                  key={entry.id}
                  entry={entry}
                  onRemove={() => remove(entry.id)}
                />
              ))}
            </div>
          )}
        </div>

        {/* 底部：清空全部 */}
        {entries.length > 0 && (
          <footer className="border-t border-gold/30 px-5 py-3">
            <button
              onClick={() => setConfirmClear(true)}
              className="inline-flex w-full items-center justify-center gap-1.5 rounded-lg border border-gold/40 px-4 py-2.5 font-display text-sm text-gold transition-colors hover:bg-gold/10"
            >
              <Trash2 size={15} /> 清空全部历史
            </button>
          </footer>
        )}
      </aside>

      {/* 清空确认 */}
      {confirmClear && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-ink/50 px-4 backdrop-blur-sm">
          <div className="animate-fadeUp w-full max-w-xs rounded-2xl border border-gold/40 bg-paper p-6 text-center shadow-lift">
            <p className="font-display text-lg font-semibold text-ink">
              要清空全部历史记录吗？
            </p>
            <p className="mt-1 font-display text-sm text-ink-soft">
              已保存的排列与故事都会被删除，无法撤销
            </p>
            <div className="mt-5 flex justify-center gap-3">
              <button
                onClick={() => setConfirmClear(false)}
                className="rounded-lg border border-gold/40 px-4 py-2 font-display text-sm text-ink-soft transition-colors hover:bg-gold/10"
              >
                再想想
              </button>
              <button
                onClick={() => {
                  clear();
                  setConfirmClear(false);
                }}
                className="rounded-lg bg-clay px-4 py-2 font-display text-sm font-semibold text-paper transition-colors hover:bg-clay-dark"
              >
                确认清空
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
