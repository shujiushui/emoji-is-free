import { useEffect, useState } from "react";

interface Props {
  text: string;
  open: boolean;
  /** 打字完成后触发 */
  onTyped?: () => void;
}

export default function ResultReveal({ text, open, onTyped }: Props) {
  const [shown, setShown] = useState(0);

  useEffect(() => {
    if (!open) {
      setShown(0);
      return;
    }
    setShown(0);
    let i = 0;
    const timer = setInterval(() => {
      i += 1;
      setShown(i);
      if (i >= text.length) {
        clearInterval(timer);
        onTyped?.();
      }
    }, 28);
    return () => clearInterval(timer);
  }, [open, text, onTyped]);

  if (!open) return null;
  const done = shown >= text.length;

  return (
    <div className="relative animate-fadeUp rounded-2xl border border-gold/40 bg-paper-200/70 p-5 shadow-paper sm:p-6">
      {/* 装饰引号 */}
      <span
        aria-hidden
        className="pointer-events-none absolute -top-3 left-4 font-display text-5xl leading-none text-gold/40"
      >
        “
      </span>

      <div className="mb-2 flex items-center justify-between">
        <span className="font-display text-sm tracking-wide text-gold">
          这段排列讲述了——
        </span>
        {done && (
          <span className="animate-stampIn rounded-md border-2 border-sage bg-sage/15 px-2 py-0.5 font-display text-xs font-bold text-sage-dark">
            已解读
          </span>
        )}
      </div>

      <p className="font-display text-[1.05rem] leading-relaxed text-ink sm:text-lg">
        {text.slice(0, shown)}
        {!done && (
          <span className="ml-0.5 inline-block h-4 w-[2px] translate-y-0.5 animate-pulse bg-clay align-middle" />
        )}
      </p>

      {done && (
        <p className="mt-3 text-sm text-ink-soft">
          换一种顺序再解读，符号们会讲出另一个故事。
        </p>
      )}
    </div>
  );
}
