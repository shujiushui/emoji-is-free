import { useCallback, useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

export interface SortableItem {
  id: string;
  emoji: string;
}

interface Props {
  items: SortableItem[];
  onChange: (items: SortableItem[]) => void;
}

const GAP = 10;

export default function SortableList({ items, onChange }: Props) {
  const [order, setOrder] = useState<string[]>(() => items.map((i) => i.id));
  const [dragId, setDragId] = useState<string | null>(null);
  const [pointer, setPointer] = useState<{ x: number; y: number } | null>(null);
  const [slotW, setSlotW] = useState(64);
  const [slotH, setSlotH] = useState(64);
  const listRef = useRef<HTMLDivElement>(null);
  const itemRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const grabOffset = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  useEffect(() => {
    setOrder(items.map((i) => i.id));
  }, [items]);

  const measure = useCallback(() => {
    const first = itemRefs.current[order[0]];
    if (!first) return;
    setSlotW(first.offsetWidth + GAP);
    setSlotH(first.offsetHeight);
  }, [order]);

  useEffect(() => {
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [measure]);

  const indexOf = (id: string) => order.indexOf(id);

  const commit = useCallback(
    (next: string[]) => {
      const map = new Map(items.map((i) => [i.id, i]));
      onChange(next.map((id) => map.get(id)!).filter(Boolean));
    },
    [items, onChange],
  );

  const handlePointerDown = (e: React.PointerEvent, id: string) => {
    e.preventDefault();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    grabOffset.current = {
      x: e.clientX - (rect.left + rect.width / 2),
      y: e.clientY - (rect.top + rect.height / 2),
    };
    setDragId(id);
    setPointer({ x: e.clientX, y: e.clientY });
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!dragId) return;
    setPointer({ x: e.clientX, y: e.clientY });
    const rect = listRef.current?.getBoundingClientRect();
    if (!rect) return;
    const rel = e.clientX - rect.left + listRef.current!.scrollLeft;
    let idx = Math.round(rel / slotW - 0.5);
    idx = Math.max(0, Math.min(order.length - 1, idx));
    const cur = indexOf(dragId);
    if (idx !== cur) {
      const next = [...order];
      next.splice(cur, 1);
      next.splice(idx, 0, dragId);
      setOrder(next);
      commit(next);
    }
  };

  const endDrag = (e: React.PointerEvent) => {
    if (!dragId) return;
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
    setDragId(null);
    setPointer(null);
  };

  const totalW = order.length * slotW;

  return (
    <div className="no-scrollbar overflow-x-auto pb-2">
      <div
        ref={listRef}
        className="relative"
        style={{ width: totalW, height: slotH }}
        onPointerMove={handlePointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
      >
        {order.map((id, i) => {
          const item = items.find((it) => it.id === id);
          if (!item) return null;
          const isDragging = dragId === id;
          return (
            <div
              key={id}
              ref={(el) => {
                itemRefs.current[id] = el;
              }}
              onPointerDown={(e) => handlePointerDown(e, id)}
              className={cn(
                "absolute top-0 flex select-none items-center justify-center rounded-xl border text-2xl shadow-paper",
                "h-12 w-12 cursor-grab touch-none bg-paper-200/90 backdrop-blur-sm",
                "border-gold/30 sm:h-14 sm:w-14 sm:text-3xl",
                "transition-[transform,box-shadow] duration-300 ease-[cubic-bezier(.2,.8,.2,1)] active:cursor-grabbing",
                isDragging && "opacity-0",
              )}
              style={{ transform: `translateX(${i * slotW}px)` }}
            >
              <span className="leading-none">{item.emoji}</span>
            </div>
          );
        })}

        {dragId &&
          pointer &&
          (() => {
            const item = items.find((it) => it.id === dragId);
            if (!item) return null;
            return (
              <div
                className="pointer-events-none fixed z-50 flex h-12 w-12 items-center justify-center rounded-xl border border-clay/60 bg-paper-200 text-2xl shadow-lift sm:h-14 sm:w-14 sm:text-3xl"
                style={{
                  left: pointer.x,
                  top: pointer.y,
                  transform: `translate(calc(-50% - ${grabOffset.current.x}px), calc(-50% - ${grabOffset.current.y}px)) scale(1.12) rotate(-4deg)`,
                }}
              >
                <span className="leading-none">{item.emoji}</span>
              </div>
            );
          })()}
      </div>
    </div>
  );
}
