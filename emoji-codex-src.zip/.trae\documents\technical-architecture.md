# Emoji 密语 · 技术架构文档

## 1. 架构设计

```mermaid
flowchart LR
    subgraph FE["前端（浏览器）"]
        UI["React 视图层<br/>地图页 / 关卡页"]
        Logic["游戏逻辑层<br/>排序校验 · 结果揭示 · 进度管理"]
        Store["本地存储<br/>localStorage"]
    end
    Data["关卡数据<br/>静态 TS 模块（无后端）"]
    Data --> UI
    UI --> Logic
    Logic --> Store
```

纯前端单页应用，无后端、无外部服务。关卡数据以内置静态模块提供，进度持久化到浏览器 localStorage。

## 2. 技术说明
- **前端**：React@18 + TypeScript + tailwindcss@3 + Vite@5
- **初始化工具**：vite-init（`npm create vite@latest`，react-ts 模板）
- **路由**：react-router-dom@6（`/` 地图页，`/level/:id` 关卡页）
- **后端**：无
- **数据库**：无；使用 localStorage 保存 `emoji-whispers-progress`（已完成关卡 id 集合）
- **拖拽排序**：基于 Pointer Events 自研轻量可排序列表（兼容鼠标与触摸），不引入额外拖拽库

## 3. 路由定义
| 路由 | 用途 |
|------|------|
| `/` | 地图主页：展示蜿蜒路径与所有关卡节点，处理进入关卡 |
| `/level/:id` | 关卡游戏页：emoji 拖拽排序、解读、结果揭示、通关流转 |
| `*` | 重定向至 `/` |

## 4. 数据模型

### 4.1 关卡数据结构
```ts
interface Level {
  id: number;            // 关卡序号，从 1 开始
  title: string;         // 关卡标题
  hint: string;          // 解谜提示
  emojis: string[];      // 正确顺序的 emoji 序列（6~7 个）
  meaning: string;       // 正确排列所表达的文字含义
  accent?: string;       // 可选节点主题色
}
```

### 4.2 进度结构
```ts
interface Progress {
  completed: number[];   // 已通关关卡 id
}
```
存储键：`emoji-whispers-progress`。解锁规则：关卡 1 默认解锁；关卡 n（n>1）在关卡 n-1 完成后解锁。

### 4.3 排序校验逻辑
- 进入关卡时，将 `emojis` 正确顺序**洗牌**（确保不等于原顺序）作为初始排列
- 玩家拖拽得到 `playerOrder`
- `isCorrect = playerOrder.every((e, i) => e === level.emojis[i])`
- 正确 → 标记完成、解锁下一关、展示成功态；错误 → 展示含义 + 鼓励文案，允许重新排列后再次解读

## 5. 组件划分
| 组件 | 职责 |
|------|------|
| `App` | 路由容器 + 全局纸张背景与字体 |
| `pages/MapPage` | 地图主页：标题、进度条、SVG 路径、关卡节点列表 |
| `pages/LevelPage` | 关卡游戏页：信息栏、排序区、解读按钮、结果区 |
| `components/LevelNode` | 地图上的单个关卡节点（状态：locked / available / done） |
| `components/SortableList` | 自研指针拖拽排序列表（纵向） |
| `components/ResultReveal` | 打字机效果的结果揭示区 + 成功印章 |
| `data/levels` | 静态关卡数据（6 关） |
| `lib/progress` | localStorage 进度读写与解锁判断 |
